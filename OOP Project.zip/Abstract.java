package OOP_Project;

public abstract class Abstract{

	  public abstract double rail();

	  public abstract String answer();
	  
	  public abstract String finalResponse();
	  
	  public abstract String finalAnswer();
	  
	  public abstract int busAnswer();
	  
	  public abstract String dilauge(); 
	  



	}