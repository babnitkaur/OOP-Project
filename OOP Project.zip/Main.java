package OOP_Project;

public class Main extends Welcome_Page{

	public static void main(String[] args) {
		Welcome_Page wp = new Welcome_Page();
		Underground u = new Underground();
		Ground g = new Ground();
		Bus b = new Bus();
		
		wp.gender();
		wp.story();
		u.story();
		
		while ( correct < 4 ) {
			u.rooms();
			u.trigger();	
			items();
			
		}
		Ground.welcome();
		Bus.welcome();
		}
		
		
		
		
		
	
}
