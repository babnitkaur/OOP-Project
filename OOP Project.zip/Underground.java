package OOP_Project;
import java.util.Random;
import java.util.Scanner;

public class Underground extends Welcome_Page {

	public Underground() {	}
	
	static Random rand = new Random();
	static int trigger = rand.nextInt(8); ;
	static int R;
	
	
	
	
	//MATH STUFF
	private static int  mathAnswer;
	public void setMathAnswer(int mathAnswer) {
		this.mathAnswer = mathAnswer;
	}

	public int getMathAnswers() {
		return mathAnswer;
	}
	
	private static int mathResponse;
	public void setMathResponse(int mathResponse) {
		Underground.mathResponse = mathResponse;
	}

	public int getMathResponse() {
		return mathResponse;
	}// end of math stuff
	
	//monster stuff
	private static String riddleAnswer;
	private static String riddleResponse;
	
	public static void setriddleAnswer(String riddleAnswer) { Underground.riddleAnswer = riddleAnswer; }

	public static String getriddleAnswers() { return riddleAnswer; }
	// end of monster stuff
	
	
	
	
	
	
	
	//items are. 1. cracker 2. key 3. shovel
	
	
	
	
	public static void story() {
		
		System.out.println(" ________________________ ");
		System.out.println(" Welcome to the underground. You need to solve math problems or riddles to collect the four items");
		System.out.println("________________________");
	}// end of story
	
	
	
	
	
	
	
	
	public static void rooms() {
		System.out.println(" Pick a number between 1 - 8 to go to a room");
		
		Scanner scanner = new Scanner(System.in);
		
		R = scanner.nextInt();
		if ( R < 9) { System.out.println(" Cool. Lets go to " + R + " room");}
		else
		{
			dead(); {
				System.out.println(" Invalid response, terminating program now");
				System.exit(0);
		}// end of dead
		
	}//end of dead
	
	
	}//end of rooms
	
	
	
	
	public static void trigger () {
		
		if ( trigger == R) {
			System.out.println(" Sucks, you got a room with a monster. Solve this riddle to live");
			monster();
		}
		else { 
			
			System.out.println(" You got a room with an item. Lets go to it");
			item();
		}
		
	}// end of trigger
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

	static void item() {
		
		System.out.println(" Welcome to room " + R + " solve the following item");
		Scanner scanner = new Scanner(System.in);
		int mp = rand.nextInt(9);

		switch (mp) {

		case 1:
			System.out.println(" your math problem is....");
			System.out.println(" what is (4 * 4) + 37 ");

			mathAnswer = 53;

			mathResponse = scanner.nextInt();
			if (mathAnswer == mathResponse) {
				System.out.println("Good job! You beat this room");
				correct++;

			} else {
				
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
				
			}

			break;
			
		case 2:
			System.out.println(" your math problem is....");
			System.out.println(" what is (72 / 4) * 6 ");

			mathAnswer = 108;

			mathResponse = scanner.nextInt();
			if (mathAnswer == mathResponse) {
				System.out.println("Good job! You beat this room");
				correct++;
			} else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}

			break;

		case 3:

			System.out.println(" your math problem is....");
			System.out.println(" what is  5 * 37 ");

			mathAnswer = 185;

			mathResponse = scanner.nextInt();
			if (mathAnswer == mathResponse) {
				System.out.println("Good job! You beat this room");
				correct++;
			} else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}
			break;

		case 4:
			System.out.println(" your math problem is....");
			System.out.println(" what is 65 * 3 ");

			mathAnswer = 195;

			mathResponse = scanner.nextInt();
			if (mathAnswer == mathResponse) {
				System.out.println("Good job! You beat this room");
				correct++;
			} else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}

			break;
		case 5:
			System.out.println(" your math problem is....");
			System.out.println(" what is 696 / 3 ");

			mathAnswer = 232;

			mathResponse = scanner.nextInt();
			if (mathAnswer == mathResponse) {
				System.out.println("Good job! You beat this room");
				correct++;
			} else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}
			break;
		case 6:
			System.out.println(" your math problem is....");
			System.out.println(" what is 93 + 43 + 37 ");

			mathAnswer = 173;

			mathResponse = scanner.nextInt();
			if (mathAnswer == mathResponse) {
				System.out.println("Good job! You beat this room");
				correct++;
			} else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}

			break;
		case 7:
			System.out.println(" your math problem is....");
			System.out.println(" what is 4 * 61 ");

			mathAnswer = 244;

			mathResponse = scanner.nextInt();
			if (mathAnswer == mathResponse) {
				System.out.println("Good job! You beat this room");
				correct++;
			} else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}
			break;
		case 8:
			System.out.println(" your math problem is....");
			System.out.println(" what is 865 / 5 ");

			mathAnswer = 173;

			mathResponse = scanner.nextInt();
			if (mathAnswer == mathResponse) {
				System.out.println("Good job! You beat this room");
				correct++;
			} else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}
			break;
		case 9:
			System.out.println(" your math problem is....");
			System.out.println(" what is 25 * 13 ");

			mathAnswer = 325;

			mathResponse = scanner.nextInt();
			if (mathAnswer == mathResponse) {
				System.out.println("Good job! You beat this room");
				correct++;
			} else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}
			break;
		case 10:
			System.out.println(" your math problem is....");
			System.out.println(" what is 85 + 15 - 53 ");

			mathAnswer = 47;

			mathResponse = scanner.nextInt();
			if (mathAnswer == mathResponse) {
				System.out.println("Good job! You beat this room");
				System.out.println("We grant you this item for your wit");
				correct++;
			} else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}
			break;
			
			
		}// end of cases

	
		
	}// end of item
	
	
	
	
	
	static void monster () {
		
		int riddles1 = rand.nextInt(4);
		Scanner scanner = new Scanner(System.in);
		switch (riddles1) {

		case 1:
			System.out.println(" you have encountered a monster! The monster speaks in riddles. ");
			System.out.println(" Solve this riddle to defeat the monster and live...");
			System.out.println("      ");
			System.out.println(
					" Throw away the outside and cook the inside, then eat the outside and throw away the inside. What is it? ");

			
			riddleAnswer = "corn on the cob";
			riddleResponse = scanner.nextLine();

			if (riddleAnswer.equals(riddleResponse)) 
				
			{

				System.out.println(" Congrats, you live to see another day.");

			}

			else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}

			break;
		case 2:

			System.out.println(" you have encountered a monster! The monster speaks in riddles. ");
			System.out.println(" Solve this riddle to defeat the monster and live...");
			System.out.println("      ");
			System.out.println(" What has hands but can not clap? ");

			riddleAnswer = "clock";
			
			riddleResponse = scanner.nextLine();

			if (riddleAnswer.equals(riddleResponse)) {

				System.out.println(" Congrats, you live to see another day.");
				
			}

			else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}

			break;

		case 3:

			System.out.println(" you have encountered a monster! The monster speaks in riddles. ");
			System.out.println(" Solve this riddle to defeat the monster and live...");
			System.out.println("      ");
			System.out.println(" What word is spelled wrong in every dictionary?");

			
			riddleAnswer = "wrong";
			riddleResponse = scanner.nextLine();

			if (riddleAnswer.equals(riddleResponse)) {

				System.out.println(" Congrats, you live to see another day.");

			}

			else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}

			break;

		case 4:

			System.out.println(" you have encountered a monster! The monster speaks in riddles. ");
			System.out.println(" Solve this riddle to defeat the monster and live...");
			System.out.println("      ");
			System.out.println(" What has a neck but no head? ");

			riddleAnswer = "bottle";
			
			riddleResponse = scanner.nextLine();

			if (riddleAnswer.equals(riddleResponse)) {

				System.out.println(" Congrats, you live to see another day.");

			}

			else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}

			break;

		case 5:

			System.out.println(" you have encountered a monster! The monster speaks in riddles. ");
			System.out.println(" Solve this riddle to defeat the monster and live...");
			System.out.println("      ");
			System.out.println(" Which weighs more, a pound of feathers or a pound of bricks? ");

			
			riddleAnswer = "neither";
			riddleResponse = scanner.nextLine();

			if (riddleAnswer.equals(riddleResponse)) {

				System.out.println(" Congrats, you live to see another day.");
				System.out.println(" Now lets pick another room ");
			}

			else {
				dead(); {
					System.out.println(" You got it wrong. You are dead. Terminating program");
					System.exit(0);
				}
			}

			break;
		
		
		
		}// end of switch
		
		

}
	
}



