package OOP_Project;
import java.util.Scanner;
public class Bus extends Welcome_Page {
	
	private static int BusAnswer;
	public void setBusAnswer(int BusAnswer) { Bus.BusAnswer = BusAnswer; }
	public int getBusAnswers() { return BusAnswer;}
	private static  String finalAnswer;
	public  void finalAnswer(String finalAnswer) { Bus.finalAnswer = finalAnswer; }
	public  String finalAnswers() { return finalAnswer;}
	
	
	private static String finalResponse;
	public void setfinalResponse(String finalResponse) { Bus.finalResponse = finalResponse; }
	public String getfinalResponse() { return finalResponse;}
	
	static Scanner scanner = new Scanner(System.in);
	
public static void welcome() {
		
		System.out.println("________________________________________________");
		System.out.println(" You made it to the bus! In order to get to the exam you must stay alive on this bus.");
		System.out.println(" You have to ");
		System.out.println(" 1: get a seat");
		System.out.println(" 2: stay behind the white line ");
		System.out.println(" 3: not get eaten by service dogs ");
		System.out.println(" 4: finally, get off the bus!");
		
		getting_Seat();
		
	}
public static void getting_Seat() {
	System.out.println("________________________________________________");
	System.out.println(" you have four seats in front of you. which seat do you choose?");
	System.out.println(" Seat 1 is next to a sorority girl ");
	System.out.println(" Seat 2 is next to a business school major ");
	System.out.println(" Seat 3 is wet ");
	System.out.println(" Seat 4 is next to a dog ");
	
	BusAnswer = scanner.nextInt();
	
	if (BusAnswer > 4 ) { 
		dead(); {
			System.out.println(" invalid response, terminating program now");
			System.exit(0);
	}
		
	}
	
	if ( BusAnswer == 4 ) {
		System.out.println(" You chose the seat next to the dog");
		System.out.println(".....................................");
		System.out.println(" You chose the right seat");
		System.out.println(" Now try to stay behind the white line...");
		whiteLine();
		
		
	}
	if ( BusAnswer == 3 ) {
		System.out.println(" You chose a wet seat "); 
		System.out.println("The seat was acidic, you died.");
		dead(); {
		}
			
			System.exit(0);
		
	//dead
		
	}
	
	if (BusAnswer == 2 ) { 
		System.out.println(" You chose the seat next to a business school major ");
		System.out.println(" Business School Major: where you are interning this summer? ");
		System.out.println(" You: Oh no where, but I wish I was...");
		System.out.println(" RBS student: Oh I'm working at Goldman Sachs, I sold my soul for that internship");
		System.out.println(" .........");
		System.out.println("You jumped out of the window so you dont have to talk to them anymore and died");
		dead(); {
		}
			
			System.exit(0);
		
	}
	
	if (BusAnswer == 1) {
		
		System.out.println(" You chose the seat next to the sorority girl");
		System.out.println(" Sorority girl: Hi OMG are u from apple kappa ligma? ");
		System.out.println(" You: No sorry you must have me mixed up with someone else");
		System.out.println(" Sorority girl: Oh ok, my sorority is recruiting new members you should TOTALLY join!! ");
		System.out.println(" You: ..........");
		System.out.println(" Sorority girl: We have lunch together, breakfast together, study at alex together, take trips to the bathroom together do... ");
		System.out.println(" You: sorry I have to go die now ");
		System.out.println("You jumped out of the window and died");
		
		dead(); {
		}
			
			System.exit(0);
		
	}
		
	
	}// end of seat

public static void whiteLine() {
	
	System.out.println("......................................");
	System.out.println(" You did it, you got a seat! ");
	System.out.println(" The dog you sat next to is making weird growling noises. You need to get up and stand next to the white line. ");
	System.out.println(" there are 2 sides to the rail you can hold onto, please select one of the rails below ");
	
	System.out.println(" Rail: 1");
	System.out.println(" Rail: 2");
	BusAnswer = scanner.nextInt();
	
	
	
	if (BusAnswer > 2 ) { dead(); {
		System.out.println(" invalid response, terminating program now");
		System.exit(0);
}
	
	}
	
	if (BusAnswer == 2 ) { 
		System.out.println(" You chose the right rail ");
		System.out.println(" you are doing great! ");
		System.out.println(" Your friend texted you a meme ");
		System.out.println(" you need both hands to screenshot the meme so you let go of the rail");
		System.out.println(" .........");
		System.out.println("The bus just braked really hard and you flew out of the window and died");
		
		dead(); {
		}
			
			System.exit(0);
		
	}
		
		
	
	
	if (BusAnswer == 1) {
		System.out.println(" ................................");
		System.out.println(" You chose the left rail ");
		System.out.println(" You are doing great! ");
		System.out.println(" your friend texted you a meme");
		System.out.println(" It was a lame meme ");
		
		System.out.println(" you held onto the railing are doing fine  ");
		System.out.println(" ......the dogs are looking at you ");
		System.out.println(" The dog is coming towards you ");
		System.out.println(" What do you do? ");
		dogs();
	}
	
	
	
}// end of white line





public static void dogs () {
	System.out.println(" ................................");
	System.out.println(" The dog is getting very close to you and trying to sniff you feet! ");
	System.out.println(" You need to do something quick! what do you do?");
	System.out.println(" 1: You try to pet it ");
	System.out.println(" 2: You kick it to get it away from you");
	System.out.println(" 3: You try to read its collar ");
	System.out.println(" 4: You try to run away from it ");
	

BusAnswer = scanner.nextInt();
	
	
	
	if (BusAnswer > 4 ) { dead(); {
		System.out.println(" invalid response, terminating program now");
		System.exit(0);
}
	
	}
	
	if (BusAnswer == 4 ) { 
		System.out.println(" You chose to try and run away from the dog ");
		System.out.println(" ...... ");
		System.out.println(" But where will you run to? It's a crowded bus ");
		System.out.println(" That was a dumnb answer");
		System.out.println(" .........");
		System.out.println("The dog ate you, you died");
		dead(); {
		}
			
			System.exit(0);
		
	
	}
	
	if (BusAnswer == 3 ) {
		
		System.out.println(" You chose to read the dogs collar ");
		System.out.println(" That was a very kind choice ");
		System.out.println(" The dog collar is in japanese");
		System.out.println(" Its a ninja dog ");
		System.out.println(" It says");
		System.out.println(" omae wa mou shindeiru   ");
		System.out.println(" ......the dogs are looking at you with its teeth out");
		System.out.println("The dog ate you, you died");
		dead(); {
		}
			
			System.exit(0);
		
	
	}
	
if (BusAnswer == 2 ) {
		
		System.out.println(" You chose to kick the dog and get it away from you ");
		System.out.println(" Its working! ");
		System.out.println(" You kicked it once, it backed off");
		System.out.println(" You tried to kick it again ");
		System.out.println(" ..........");
		System.out.println(" The dog got a hold of your foot in his mouth  ");
		System.out.println(" ............ It flipped you and you landed on your neck ");
		System.out.println("The dog ate you, you died");
		dead(); {
		}
			
			System.exit(0);
		
	
	}

if (BusAnswer == 1 ) {

System.out.println(" You chose to try and pet the dog ");
System.out.println(" The dog is looking at you angrily ");
System.out.println(" But slowly.....");
System.out.println(" he seems to....... ");
System.out.println(" ..........");
System.out.println(" Like you  ");
System.out.println(" You survived the dog");
System.out.println(" Now you need to get off the bus and make it to your exam ");
leaving(); }

}// end of dogs

public static void leaving() {
	
	
	System.out.println(" .........................................................");
	System.out.println(" You're almost there! ");
	System.out.println(" The home streach ");
	System.out.println(" There are two people ahead of you. They wont let you leave until you solve this one riddle ");
	System.out.println(" The riddle is.....");
	System.out.println(" Akash teaches OOP, what is his favorite word?");
	
	Scanner scanner = new Scanner(System.in);
	finalAnswer = scanner.nextLine();
	
	
	if ( finalAnswer.equals("instantiate")) 
	{
		System.out.println(" You did it! You remembered the one word akash loves so much. You safely left the bus and made it to your exam");
		finish();
		
	}
	else {
		System.out.println("You dont remember the one word Akash loves so much? You should rot in the bus.");
		dead(); {
		}
			
			System.exit(0);
		
	
	}
		
	
	
	
}// end of leaving

public static void finish() {
	
	
	System.out.println(" Congrats! ");
	System.out.println(" ");
	System.out.println(" YOU DID IT! YOU GOT OUT OF THE GORUND, CONVINCED PEOPLE YOURE NOT A ZOMBIE AND MADE IT TO YOUR EXAM");
	System.out.println(" We hope you had fun playing Nightmare. We wish you luck on your exam and don't pull all nighters again! ");
	System.exit(0);
}


}
