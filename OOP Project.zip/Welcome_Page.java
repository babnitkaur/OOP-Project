package OOP_Project;
import java.util.Scanner;
import java.util.*;

public class Welcome_Page {
	
	public Welcome_Page() {
	}
	
	
	public static void gender() {
		
		System.out.println("Hello! Welcome to Nightmare! please select your gender.");
		System.out.println("Please type 'M' for male or type 'F' for female ");
		Scanner scanner = new Scanner(System.in);
		String n = scanner.next();
		
		String G = n.toUpperCase(); 
		
		
		if (G.equals("M")) {
			System.out.println("You are a male in this game");
			System.out.println("_________________________________________________");}
		
		else if (G.equals("F")) {
			
			System.out.println("You are a female in this game");
			System.out.println("_________________________________________________");
		}
		
		else { System.out.println("Invalid response, terminating program now");
		System.exit(0);}
		
	
	}// end of gender
	
	public static void story() {
		
		System.out.println(
				"You are very desperate to pass your OOP Exam tomorrow and are pulling an all nighter studying.");
		System.out.println(
				" While studying through the wee hours of the night, you don't realize when you knocked out. ");
		System.out.println("To your horror, you wake up underground!");
		System.out.println(
				" It is now up to you to get back to the surface and survive all the obstacles to take the exam before,");
		System.out.println("UWUPS! you're dead.");
		System.out.println(
				" Let's see if you can save yourself from the greatest horrors of being a Rutgers Student. Game ON!");

	}// end of story
	
	
	//THESE ARE SOME OF THE POLYMOPHIC THINGS WE ARE GONNA USE
	//used it
	static void next_level() {
		System.out.println(" Good job, lets go to ___________");
		
	}
//used it
	static void dead() {
		System.out.println(" You failed, terminating program now");
		System.exit(0);
	}
	
	static void items() {
		
		if ( correct == 1) {
			System.out.println(" We grant you a key");
			}
			if( correct == 2) {System.out.println(" we grant you some crackers");}
			if(correct == 3) { System.out.println(" we grant you a shovel");}
			if (correct == 4) { System.out.println(" we grant you a torch");
			}
			else {System.out.println("dd");}
			}
	
		
	
	
	//correct. used it
	static int correct = 0;
	
	
		
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	


