package OOP_Project;
import java.util.Random;
import java.util.Scanner;
public class Ground extends Welcome_Page {
public Ground() {}

	private static int dilauge;
	public void setL2Answer(int dialauge) { dilauge = dilauge; }
	public int getL2Answers() { return dilauge;}
	static Scanner scanner = new Scanner(System.in);
	public static void welcome() {
		System.out.println("__________________________________________");
		System.out.println(" Congrats on passing to the next stage!");
		System.out.println(" You have used the four items to dig yourself out to the surface level. ");
		System.out.println(" 5 people watched you crawl out of the ground, it seems fishy.....");
		System.out.println(" You need to now talk to all five of them and convince them you are not a zombie ");
		System.out.println(" But be careful");
		System.out.println(" If 2 of them think you are a zombie they will");
		System.out.println(" KILL ");
		System.out.println(" YOU ");
		alex();
		}// end of welcome
	
	
	//the five people are
			//alex
			//maria
			//radha
			//patrick
			//lana
			//THESE DONT HAVE ELSE STATEMENTS BECAUSE WE ARE USING TEXT BOX GUI FOR COMMANDS NOT TEXT INPUT	
		public static void alex () {
			System.out.println("__________________________________________");
			System.out.println(" Alex: wh....who are you?");
			System.out.println(" ");
		
			System.out.println(" waht do you say?");
			System.out.println(" 1: It doesnt matter, mind your business ");
			System.out.println(" 2: Run if you care about your life ");
			System.out.println(" 3: I dont know why I was underground but I think I have an exam today ");
			dilauge = scanner.nextInt();
			
			if ( dilauge == 3 ) { 
				
				System.out.println(" Alex: oh man, do you mean the OOP exam? "); //RIGHT ANSWER
				System.out.println(" ");
				System.out.println(" Player: yes! ");
				System.out.println(" Alex: go talk to maria over there.");
				
				 maria();
				}
			
			if ( dilauge == 2 ) { System.out.println(" Not if I kill you first "); 
			}
			if ( dilauge == 1) { System.out.println(" I'm calling the police "); 
			;}
			
		
		}
		
		public static void maria() {
			System.out.println("__________________________________________");
			System.out.println(" Maria: wh....who are you?");
			System.out.println(" ");
		
			System.out.println(" waht do you say?");
			System.out.println(" 1: I need directions to the OOP exam ");
			System.out.println(" 2: I dont know...but I am hungry ");
			System.out.println(" 3: Can you fill out a quick survery on my phone? It needs your number and check off if youre single or not ");
			dilauge = scanner.nextInt();
			
			if ( dilauge == 3 ) { 
				
				System.out.println(" Maria: Ew creep, I'm calling the police");
				
					
				}
			
			if ( dilauge == 2 ) { System.out.println(" Maria: I knew zombies were real! "); 
			}
			if ( dilauge == 1) {
				System.out.println(" Maria: I just took it last week. Is it with Akash? "); //RIGHT ANSWER
				System.out.println(" ");
				System.out.println(" Player: yes! ");
				System.out.println(" Maria: Its in the SCI building on college ave");}
				System.out.println(" Player: What time is the exam? ");
				System.out.println(" Maria: I dont know, ask Radha over there ");
				radha();
			}	
		
		public static void radha() {
			
			System.out.println("__________________________________________");
			System.out.println(" Radha: Why did you just crawl out of the ground?");
			System.out.println(" ");
			
			System.out.println(" waht do you say?");
			System.out.println(" 1: I dont know how I got there but I I need to get to College Ave for my OOP exam ");
			System.out.println(" 2: Sometimes I just like to go underground for a month or two ");
			System.out.println(" 3: I was in a bar fight and next thing I know is I'm underground ");
			dilauge = scanner.nextInt();
			
			if ( dilauge == 3 ) { 
				
				System.out.println(" Radha: ZOMBIE ZOMBIE HELPPP ");
				
					
				}
			
			if ( dilauge == 2 ) { System.out.println(" Radha: I knew zombies were real! "); 
			}
			if ( dilauge == 1) {
				System.out.println(" Radha: Oh you you better hurry fast. It's at 2:40 pm "); //RIGHT ANSWER
				System.out.println(" ");
				System.out.println(" Player: Whats the quickest way to get there? ");
				System.out.println(" Radha: I'm a freshman so I dont really know the bus system too well ");}
				System.out.println(" Player: I'm a freshman too ");
				System.out.println(" Radha: Patrick over there is a sophmore, he might know  ");
				patrick();
		}
		
		
		public static void patrick() {
			System.out.println("__________________________________________");
			
			System.out.println(" Patrick: Are you a zombie?");
			System.out.println(" ");
	
			System.out.println(" waht do you say?");
			System.out.println(" 1: Yuh ");
			System.out.println(" 2: Nah ");
			System.out.println(" 3: No but please tell me how to get to College Ave I need to take the OOP exam at 2:40 ");
			dilauge = scanner.nextInt();
			
			if ( dilauge == 1 ) { 
				
				System.out.println(" Patrick: Atleast youre honest, now I wont feel bad about killing you ");
				
					
				}
			
			if ( dilauge == 2 ) { System.out.println(" Patrick: Liar! Die! "); 
			}
			if ( dilauge == 3) {
				System.out.println(" Patrick: Zombies dont have exams so you must be real. Take the LX"); //RIGHT ANSWER
				System.out.println(" ");
				System.out.println(" Player: Should I take the Student Center stop or the Livi Plaza Stop? ");
				System.out.println(" Patrick: Actually, ask Lana over there ");}
			
				lana();
		}
		
		public static void lana() {
			System.out.println("__________________________________________");
			System.out.println(" Lana: Woah you startled me!");
			System.out.println(" ");
		
			System.out.println(" waht do you say?");
			System.out.println(" 1: Good, I'm a zombie and I need your brain ");
			System.out.println(" 2: Hehe sowwy I <3 u ");
			System.out.println(" 3: Sorry, can you tell me which bus stop is faster if I want to get to College Ave?");
			dilauge = scanner.nextInt();
			
			if ( dilauge == 1 ) { 
				
				System.out.println(" Lana: AHHHH ZOMBIEEE HELPP ");
				
					
				}
			
			if ( dilauge == 2 ) { System.out.println(" Lana: Ew only zombies are this cringe! "); 
			}
			if ( dilauge == 3) {
				System.out.println(" Lana: Oof thats tough. I would say take the student center stop since it has more busses"); //RIGHT ANSWER
				System.out.println(" ");
				System.out.println(" Player: Thank you! ");
				System.out.println(" Lana: Good luck!");
				
				System.out.println("_____________________");
				 next_level(); {
					System.out.println(" Good job, lets go to the bus now");
					
				}
			}
			
			
			
		}
		
}
